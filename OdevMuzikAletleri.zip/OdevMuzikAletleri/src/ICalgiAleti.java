
public interface ICalgiAleti {
public void cal();
}
