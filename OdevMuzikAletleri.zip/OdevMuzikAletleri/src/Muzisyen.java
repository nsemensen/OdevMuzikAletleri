public class Muzisyen {

	private String name;

	public Muzisyen(String name) {
		this.name = name;
	}

	public void calgiAletiEkle(MuzikAleti[] muzikAletleri) {
		for (MuzikAleti muzikAleti : muzikAletleri) {
			muzikAleti.getTur();
		}
	}

	public void muzikCal(ICalgiAleti CalgiAleti) {
		if (CalgiAleti instanceof MuzikAleti) {
			MuzikAleti cA = (MuzikAleti) CalgiAleti;
			System.out.println(this.name + " isimli müzisyen " + cA.getTur() + " türünde müzik aletini Kullanıyor.");
		} else {
			System.out.println(this.name + " isimli müzisyen herhangi bir müzik aleti çalmıyor");
		}
		CalgiAleti.cal();
	}

	public String getName() {
		return name;
	}
}
