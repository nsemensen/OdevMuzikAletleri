
public abstract class MuzikAleti implements ICalgiAleti {

	private String tur; // telli / vurmalı / nefesli / üflemeli / tuşlu / yaylı
	 // kanun, bağlama / davul, bateri / flüt, klarnet / kaval, çello / piyano, org /
							// Keman, kemençe

	public String getTur() {
		return tur;
	}

	public void setTur(String tur) {
		this.tur = tur;
	}
	public MuzikAleti(String tur) {
		this.tur = tur;
	}
}
