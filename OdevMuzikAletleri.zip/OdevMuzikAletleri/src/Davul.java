
public class Davul extends MuzikAleti {

	private String tur;

	public Davul(String tur) {
		super(tur);
		this.tur = tur;
	}

	@Override
	public void cal() {
		System.out.println("Davul çalgı aleti ile çalınıyor.");
	}
}
