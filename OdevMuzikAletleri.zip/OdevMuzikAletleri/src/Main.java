public class Main {

	public static void main(String[] args) {
		// telli / vurmalı / nefesli / üflemeli / tuşlu / yaylı
		// kanun, bağlama / davul, bateri / flüt, klarnet / kaval, çello / piyano, org /
		// Keman, kemençe

		Muzisyen muzisyen1 = new Muzisyen("semen");

		Davul dv = new Davul("Vurmalı");
		Gitar gt = new Gitar("Telli");
		Piyano py = new Piyano("Tuşlu");

		MuzikAleti[] mAletleri = { dv, gt, py };
		muzisyen1.calgiAletiEkle(mAletleri);

		for (int i = 0; i < mAletleri.length; i++) {
			muzisyen1.muzikCal(mAletleri[i]);
		}
	}
}
