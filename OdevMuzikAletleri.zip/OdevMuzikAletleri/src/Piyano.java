
public class Piyano extends MuzikAleti {
	
	private String tur;
	
	public Piyano(String tur) {
		super(tur);
		this.tur = tur;
	}
	@Override
	public void cal() {
		System.out.println("Piyano çalgı aleti ile çalınıyor.");
	} 
}
