
public class Gitar extends MuzikAleti {
	
	private String tur;
	
	public Gitar(String tur) {
		super(tur);
		this.tur = tur;
	}

	@Override
	public void cal() {
		System.out.println("Gitar çalgı aleti ile çalınıyor.");

	} 
}
